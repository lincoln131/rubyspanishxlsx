Place XLSX file in this directory, then click Portable_Speaking.bat.
The XLSX file must be named speaking.xlsx. Case is important.

Number of objectives and where each of the objectives start is hard coded in for simplicity.

The number of standards is hard coded as well. 

The number of students has a default of 39. This can be changed at runtime.

The excel sheet will open when the program runs successfully.

