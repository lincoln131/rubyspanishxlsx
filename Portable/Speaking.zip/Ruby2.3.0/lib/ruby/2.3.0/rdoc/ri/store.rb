# frozen_string_literal: false
module RDoc::RI

  Store = RDoc::Store # :nodoc:

end

